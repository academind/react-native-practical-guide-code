import React from 'react';

const App = () => {
  return <h1>A React App!</h1>;
};

export default App;
