import AuthContent from '../components/Auth/AuthContent';

function LoginScreen() {
  return <AuthContent isLogin />;
}

export default LoginScreen;
