import { Text } from 'react-native';

export default function App() {
  return <Text>Todo...</Text>;
}
