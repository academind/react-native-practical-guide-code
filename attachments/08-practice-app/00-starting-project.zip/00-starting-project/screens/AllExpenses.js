import { Text } from 'react-native';

function AllExpenses() {
  return <Text>AllExpenses Screen</Text>;
}

export default AllExpenses;
