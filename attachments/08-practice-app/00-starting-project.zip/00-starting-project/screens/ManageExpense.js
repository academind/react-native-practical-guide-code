import { Text } from 'react-native';

function ManageExpense() {
  return <Text>ManageExpense Screen</Text>;
}

export default ManageExpense;
