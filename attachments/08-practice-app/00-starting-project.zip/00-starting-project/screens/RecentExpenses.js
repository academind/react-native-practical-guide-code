import { Text } from 'react-native';

function RecentExpenses() {
  return <Text>RecentExpenses Screen</Text>;
}

export default RecentExpenses;
